package observer2;

public class BinaryObserver extends Observer {

    @Override
    public void update(int state) {
        System.out.println("Binary String: " + Integer.toBinaryString(state));
    }
}
