package observer2;

public class OctalObserver extends Observer {

    @Override
    public void update(int state) {
        System.out.println("Octal String: " + Integer.toOctalString(state));
    }
}
