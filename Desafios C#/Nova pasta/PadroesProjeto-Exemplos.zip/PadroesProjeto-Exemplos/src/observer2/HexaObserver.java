package observer2;

public class HexaObserver extends Observer {

    @Override
    public void update(int state) {
        System.out.println("Hex String: " + Integer.toHexString(state).toUpperCase());
    }
}
