package chainofresponsibility;

public interface HelpInterface {

    public void getHelp(int helpConstant);
}
