package composite;

public class Machine extends MachineComponent {

    public int getMachineCount() {
        return 1;
    }
}
