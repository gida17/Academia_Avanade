package composite;

import java.util.ArrayList;
import java.util.List;

public class MachineComposite extends MachineComponent {

    protected List<MachineComponent> components = new ArrayList<MachineComponent>();

    public void add(MachineComponent component) {
        components.add(component);
    }

    public int getMachineCount() {
        int contador = 0;
        for (MachineComponent mc : components) {
            contador += mc.getMachineCount();
        }
        return contador;
    }
}
