package composite;

public abstract class MachineComponent {

    public abstract int getMachineCount();

    public void add(MachineComponent component) {

    }
}
