package composite;

public class Cliente {

    public static void main(String[] args) {
        MachineComponent m1 = new Machine();
        MachineComponent m2 = new Machine();
        MachineComponent m3 = new Machine();
        MachineComponent m4 = new Machine();
        MachineComponent m5 = new Machine();
        MachineComponent mc1 = new MachineComposite();
        MachineComponent mc2 = new MachineComposite();
        MachineComponent mc3 = new MachineComposite();
        mc1.add(m1);
        mc1.add(m2);
        mc2.add(m3);
        mc2.add(m4);
        mc3.add(m5);
        mc3.add(mc1);
        mc3.add(mc2);
        System.out.println("Quantidade de componentes: " + mc3.getMachineCount());
    }
}
