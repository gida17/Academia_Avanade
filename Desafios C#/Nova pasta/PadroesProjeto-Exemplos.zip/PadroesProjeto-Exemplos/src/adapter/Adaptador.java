package adapter;

public class Adaptador extends Shape {

    private RasterBox rasterBox;

    public Adaptador(int x, int y, int height, int width) {
        super(x, y, height, width);
        Coords tl = new Coords(x, y);
        Coords br = new Coords(x + width, y - height);
        rasterBox = new RasterBox(tl, br);
    }

    public int getX() {
        return rasterBox.getTopLeft().getX();
    }

    public int getY() {
        return rasterBox.getTopLeft().getY();
    }

    public int getHeight() {
        return Math.abs(rasterBox.getTopLeft().getY() - rasterBox.getBottomRight().getY());
    }

    public int getWidth() {
        return Math.abs(rasterBox.getTopLeft().getX() - rasterBox.getBottomRight().getX());
    }
}
