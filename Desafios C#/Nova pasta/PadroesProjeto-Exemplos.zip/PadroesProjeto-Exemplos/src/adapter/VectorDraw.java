package adapter;

public class VectorDraw {

    public static void main(String[] args) {
        Shape s = new Adaptador(2, 4, 1, 3);
        int x = s.getX();
        int y = s.getY();
        int height = s.getHeight();
        int width = s.getWidth();
        System.out.println("Ponto inicial: (" + x + ", " + y + ")");
        System.out.println("Altura.......: " + height);
        System.out.println("Largura......: " + width);
    }
}
