package adapter;

public class RasterBox {

    private Coords topLeft, bottomRight;

    public RasterBox(Coords tl, Coords br) {
        this.topLeft = tl;
        this.bottomRight = br;
    }

    public Coords getTopLeft() {
        return topLeft;
    }

    public Coords getBottomRight() {
        return bottomRight;
    }
}
