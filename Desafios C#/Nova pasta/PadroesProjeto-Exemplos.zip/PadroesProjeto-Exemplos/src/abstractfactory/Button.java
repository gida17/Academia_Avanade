package abstractfactory;

public interface Button {

    public void paint();
}
