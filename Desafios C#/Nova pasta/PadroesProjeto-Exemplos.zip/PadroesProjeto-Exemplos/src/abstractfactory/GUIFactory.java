package abstractfactory;

public interface GUIFactory {

    public Button createButton();
}
