package prototype;

public class CoconutCookie extends Cookie {

}
