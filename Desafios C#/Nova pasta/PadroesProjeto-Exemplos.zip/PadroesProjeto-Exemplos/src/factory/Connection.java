package factory;

public abstract class Connection {

    public Connection() {
    }

    public String description() {
        return "Generic";
    }
}
