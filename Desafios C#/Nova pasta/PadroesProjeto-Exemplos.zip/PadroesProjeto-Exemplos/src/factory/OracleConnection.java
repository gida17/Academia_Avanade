package factory;

public class OracleConnection extends Connection {

    public OracleConnection() {
    }

    public String description() {
        return "Oracle";
    }
}
