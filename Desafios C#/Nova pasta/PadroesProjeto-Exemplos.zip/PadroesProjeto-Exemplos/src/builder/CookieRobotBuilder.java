package builder;

public class CookieRobotBuilder extends RobotBuilder {

    public CookieRobotBuilder() {
        robot = new CookieRobotBuildable();
    }
}
