package builder;

public class CookieRobotBuildable extends RobotBuildable {

    public void getParts() {
        System.out.println("Getting flour and sugar....");
    }

    public void assemble() {
        System.out.println("Baking a cookie....");
    }

    public void test() {
        System.out.println("Crunching a cookie....");
    }
}
