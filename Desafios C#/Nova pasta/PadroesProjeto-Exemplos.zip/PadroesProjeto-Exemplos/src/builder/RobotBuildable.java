package builder;

import java.util.ArrayList;

public abstract class RobotBuildable {

    ArrayList<Integer> actions;

    public final void go() {
        for (Integer i : actions) {
            switch (i) {
                case 1:
                    start();
                    break;
                case 2:
                    getParts();
                    break;
                case 3:
                    assemble();
                    break;
                case 4:
                    test();
                    break;
                case 5:
                    stop();
                    break;
            }
        }
    }

    public void start() {
        System.out.println("Starting....");
    }

    public void getParts() {
        System.out.println("Getting parts....");
    }

    public void assemble() {
        System.out.println("Assembling....");
    }

    public void test() {
        System.out.println("Testing....");
    }

    public void stop() {
        System.out.println("Stopping....");
    }

    public void loadActions(ArrayList<Integer> a) {
        actions = a;
    }
}
