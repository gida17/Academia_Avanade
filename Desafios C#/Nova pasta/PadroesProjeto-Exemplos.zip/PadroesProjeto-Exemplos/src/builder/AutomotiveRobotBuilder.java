package builder;

public class AutomotiveRobotBuilder extends RobotBuilder {

    public AutomotiveRobotBuilder() {
        robot = new AutomotiveRobotBuildable();
    }
}
