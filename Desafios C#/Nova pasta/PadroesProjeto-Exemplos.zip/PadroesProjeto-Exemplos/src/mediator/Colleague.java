package mediator;

public abstract class Colleague {

    protected Mediator mediator;

    public void setMediator(Mediator m) {
        mediator = m;
    }

    abstract public void go();
}
