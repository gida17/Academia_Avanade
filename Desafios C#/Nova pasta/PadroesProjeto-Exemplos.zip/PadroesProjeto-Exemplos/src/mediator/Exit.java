package mediator;

public class Exit extends Colleague {

    public Exit(Mediator m) {
        this.setMediator(m);
    }

    public void go() {
        System.out.println("Please come again sometime.");
    }
}
