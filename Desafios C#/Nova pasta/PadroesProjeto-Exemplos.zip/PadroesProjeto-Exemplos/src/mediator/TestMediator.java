package mediator;

public class TestMediator {

    public static void main(String args[]) {
        new TestMediator();
    }

    public TestMediator() {
        Mediator mediator = new Mediator();
        mediator.getWelcome().go();
    }
}
