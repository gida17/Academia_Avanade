package bridge;

public class DP1 {

    static public void draw_a_line(
            double x1, double y1,
            double x2, double y2) {
        // implementation
        System.out.println("DP1.drawline: (" + x1 + "," + y1 + ") e (" + x2 + "," + y2 + ")");
    }

    static public void draw_a_circle(
            double x, double y, double r) {
        // implementation
        System.out.println("DP1.drawcircle: (" + x + "," + y + ") e raio = " + r);
    }
}
