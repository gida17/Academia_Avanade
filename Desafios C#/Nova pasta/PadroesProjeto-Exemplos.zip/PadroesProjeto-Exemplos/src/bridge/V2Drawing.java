package bridge;

public class V2Drawing extends Drawing {

    @Override
    public void drawCircle(double x, double y, double r) {
        // TODO Auto-generated method stub
        DP2.drawcircle(x, y, r);
    }

    @Override
    public void drawLine(double x1, double y1, double x2, double y2) {
        // TODO Auto-generated method stub
        // arguments are different in DP2
        // and must be rearranged
        DP2.drawline(x1, x2, y1, y2);
    }

}
