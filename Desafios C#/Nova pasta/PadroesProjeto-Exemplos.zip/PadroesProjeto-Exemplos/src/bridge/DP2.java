package bridge;

public class DP2 {

    static public void drawline(double x1, double x2, double y1, double y2) {
        // implementation
        System.out.println("DP2.drawline: (" + x1 + "," + y1 + ") e (" + x2 + "," + y2 + ")");
    }

    static public void drawcircle(double x, double y, double r) {
        // implementation
        System.out.println("DP2.drawcircle: (" + x + "," + y + ") e raio = " + r);
    }
}
