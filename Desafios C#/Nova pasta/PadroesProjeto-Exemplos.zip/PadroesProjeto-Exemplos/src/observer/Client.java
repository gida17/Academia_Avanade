package observer;

public class Client {

    public static void main(String[] args) {
        ObservableData sc = new ObservableData();
        sc.add(new ConcreteObserver("Observador A"));
        sc.add(new ConcreteObserver("Observador B"));
        Observer c = new ConcreteObserver("Observador C");
        sc.add(c);
        sc.setData("Mensagem do ");
        sc.remove(c);
        sc.setData("Mensagem do ");
    }
}
