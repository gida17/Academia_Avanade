package observer;

public class ObservableData extends Observable {

    private Object myData;

    public void setData(Object myData) {
        this.myData = myData;
        notificar();
    }

    public Object getData() {
        return myData;
    }
}
