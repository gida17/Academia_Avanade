package observer;

import java.util.ArrayList;

public class Observable {

    ArrayList<Observer> observers = new ArrayList<Observer>();

    public void add(Observer o) {
        observers.add(o);
    }

    public void remove(Observer o) {
        observers.remove(o);
    }

    public void notificar() {
        for (Observer o : observers) {
            o.update(this);
        }
    }
}
