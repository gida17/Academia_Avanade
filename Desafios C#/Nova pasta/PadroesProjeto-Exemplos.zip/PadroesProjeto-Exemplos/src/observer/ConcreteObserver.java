package observer;

public class ConcreteObserver implements Observer {

    private String message;

    public ConcreteObserver(String mensagem) {
        this.message = mensagem;
    }

    public void update(Observable o) {
        ObservableData data = (ObservableData) o;

        System.out.println(data.getData() + this.message);
    }
}
