package proxy;

import java.awt.*;
import javax.swing.*;

public class VirtualProxyTest extends JFrame {

    private static String IMAGE_NAME = "f_16.jpg";
    private static int IMAGE_WIDTH = 256, IMAGE_HEIGHT = 256,
            SPACING = 5, FRAME_X = 150, FRAME_Y = 200, FRAME_WIDTH = 530,
            FRAME_HEIGHT = 286;
    private Icon imageIcon = null, imageIconProxy = null;

    static public void main(String args[]) {
        VirtualProxyTest app = new VirtualProxyTest();
        app.setVisible(true);
    }

    public VirtualProxyTest() {
        super("Virtual Proxy Test");
        // Create an image icon and an image-icon proxy.
        imageIcon = new ImageIcon(IMAGE_NAME);
        imageIconProxy = new ImageIconProxy(IMAGE_NAME,
                IMAGE_WIDTH,
                IMAGE_HEIGHT);
        // Set the bounds of the frame, and the frame's default
        // close operation.
        setBounds(FRAME_X, FRAME_Y, FRAME_WIDTH, FRAME_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void paint(Graphics g) {
        super.paint(g);
        Insets insets = getInsets();
        imageIcon.paintIcon(this, g, insets.left, insets.top);
        imageIconProxy.paintIcon(this, g,
                insets.left + IMAGE_WIDTH + SPACING, // width
                insets.top); // height
    }
}
