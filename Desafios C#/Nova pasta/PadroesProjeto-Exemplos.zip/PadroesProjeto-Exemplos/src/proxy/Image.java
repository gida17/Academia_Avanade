package proxy;

public interface Image {

    public void displayImage();
}
