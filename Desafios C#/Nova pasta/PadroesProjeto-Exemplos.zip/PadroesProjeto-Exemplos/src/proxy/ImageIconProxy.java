package proxy;

import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;

public class ImageIconProxy implements Icon {

    private Icon realIcon = null;
    boolean isIconCreated = false;
    private String imageName;
    private int width, height;

    public ImageIconProxy(String imageName, int width, int height) {
        this.imageName = imageName;
        this.width = width;
        this.height = height;
    }

    public int getIconHeight() {
        return isIconCreated ? height : realIcon.getIconHeight();
    }

    public int getIconWidth() {
        return isIconCreated ? width : realIcon.getIconWidth();
    }

    // The proxy's paint() method is overloaded to draw a border
    // and a message ("Loading image...") while the image 
    // loads. After the image has loaded, it is drawn. Notice
    // that the proxy does not load the image until it is
    // actually needed.
    public void paintIcon(final Component c,
            Graphics g, int x, int y) {
        if (isIconCreated) {
            realIcon.paintIcon(c, g, x, y);
        } else {
            g.drawRect(x, y, width - 1, height - 1);
            g.drawString("Loading image...", x + 20, y + 20);
            // The icon is created (meaning the image is loaded)
            // on another thread. 
            synchronized (this) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        try {
                            // Slow down the image-loading process.
                            Thread.sleep(2000);
                            // ImageIcon constructor creates the image.
                            realIcon = new ImageIcon(imageName);
                            isIconCreated = true;
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                        // Repaint the icon's component after the
                        // icon has been created.
                        c.repaint();
                    }
                });
            }
        }
    }
}
