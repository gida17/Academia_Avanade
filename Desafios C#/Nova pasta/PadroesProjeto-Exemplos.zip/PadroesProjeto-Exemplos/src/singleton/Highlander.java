package singleton;

public class Highlander {

    public int i;

    private Highlander() {
    }
    private static Highlander instancia;

    public static Highlander obterInstancia() {
        if (instancia == null) {
            instancia = new Highlander();
        }
        return instancia;
    }
}
