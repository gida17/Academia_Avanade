package singleton;

public class Fabrica {

    public static void main(String[] args) {
        Highlander h2, h3;
        //Highlander h1 = new Highlander(); // n�o compila! 
        h2 = Highlander.obterInstancia();
        h3 = Highlander.obterInstancia();
        if (h2 == h3) {
            System.out.println("h2 e h3 s�o mesmo objeto!");
        }
        // Alterando o valor do atributo 'i' pelo identificador h2
        h2.i = 2;
        if (h2.i == h3.i) {
            System.out.println("h2 e h3 realmente s�o mesmo objeto!");
        }
    }
}
