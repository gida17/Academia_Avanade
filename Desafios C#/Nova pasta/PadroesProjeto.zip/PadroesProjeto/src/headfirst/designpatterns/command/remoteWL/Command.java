package headfirst.designpatterns.command.remoteWL;

public interface Command {
	public void execute();
}
