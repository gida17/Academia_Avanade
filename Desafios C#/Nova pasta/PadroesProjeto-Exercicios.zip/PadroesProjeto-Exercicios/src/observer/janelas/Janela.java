package observer.janelas;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;

public class Janela extends javax.swing.JFrame {

    private final Modelo modelo = new Modelo();

    public Janela() {
        initComponents();
    }

    private void initComponents() {
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jComboBox1 = new JComboBox();
        jPanel2 = new JPanel();
        jLabel2 = new JLabel();
        jList1 = new JList();
        jPanel3 = new JPanel();
        jLabel3 = new JLabel();
        jTextField1 = new JTextField();
        jPanel4 = new JPanel();
        jLabel4 = new JLabel();
        jSlider1 = new JSlider();

        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Design Pattenrs - Observer");
        jLabel1.setText("Valor:");
        jPanel1.add(jLabel1);

        jComboBox1.setModel(new DefaultComboBoxModel(new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
        jComboBox1.addActionListener((ActionEvent evt) -> {
            jComboBox1ActionPerformed(evt);
        });

        jPanel1.add(jComboBox1);

        getContentPane().add(jPanel1);

        jLabel2.setText("Valor:");
        jPanel2.add(jLabel2);

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};

            @Override
            public int getSize() {
                return strings.length;
            }

            @Override
            public Object getElementAt(int i) {
                return strings[i];
            }
        });
        jList1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jList1.setMaximumSize(new Dimension(50, 176));
        jList1.setMinimumSize(new Dimension(50, 176));
        jList1.setPreferredSize(new Dimension(50, 176));
        jList1.setSelectedIndex(0);
        jList1.addListSelectionListener((ListSelectionEvent evt) -> {
            jList1ValueChanged(evt);
        });

        jPanel2.add(jList1);

        getContentPane().add(jPanel2);

        jLabel3.setText("Valor:");
        jPanel3.add(jLabel3);

        jTextField1.setText("0");
        jTextField1.setMinimumSize(new Dimension(50, 19));
        jTextField1.setPreferredSize(new Dimension(50, 19));
        jTextField1.addActionListener((ActionEvent evt) -> {
            jTextField1ActionPerformed(evt);
        });

        jPanel3.add(jTextField1);

        getContentPane().add(jPanel3);

        jLabel4.setText("Valor:");
        jPanel4.add(jLabel4);

        jSlider1.setMajorTickSpacing(1);
        jSlider1.setMaximum(10);
        jSlider1.setPaintLabels(true);
        jSlider1.setPaintTicks(true);
        jSlider1.setSnapToTicks(true);
        jSlider1.setValue(0);
        jSlider1.addChangeListener((ChangeEvent evt) -> {
            jSlider1StateChanged(evt);
        });

        jPanel4.add(jSlider1);

        getContentPane().add(jPanel4);

        pack();
    }

    private void jSlider1StateChanged(ChangeEvent evt) {
        int valor = jSlider1.getValue();
        modelo.setValor(valor);
        System.out.println("Modelo agora vale " + modelo.getValor());
    }

    private void jTextField1ActionPerformed(ActionEvent evt) {
        try {
            int valor = Integer.parseInt(jTextField1.getText());
            if ((valor < 0) || (valor > 10)) {
                throw new Exception();
            }
            modelo.setValor(valor);
            System.out.println("Modelo agora vale " + modelo.getValor());
        } catch (Exception e) {
            System.out.println("Erro: use valor de 0 a 10!");
        }
    }

    private void jList1ValueChanged(ListSelectionEvent evt) {
        int idx = jList1.getSelectedIndex();
        if (idx != -1) {
            Object selected = jList1.getModel().getElementAt(idx);
            int valor = Integer.parseInt(selected.toString());
            modelo.setValor(valor);
            System.out.println("Modelo agora vale " + modelo.getValor());
        }
    }

    private void jComboBox1ActionPerformed(ActionEvent evt) {
        int valor = Integer.parseInt(jComboBox1.getModel().getSelectedItem().toString());
        modelo.setValor(valor);
        System.out.println("Modelo agora vale " + modelo.getValor());
    }

    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JList jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JTextField jTextField1;
}
