package observer.janelas;

/**
 * Modelo único para todos os componentes gráficos.
 *
 * @author Vítor Souza
 * @version 2005.07.21
 */
public class Modelo {

    /**
     * Valor do modelo.
     */
    private int valor;

    /**
     * Getter for valor.
     */
    public int getValor() {
        return valor;
    }

    /**
     * Setter for valor.
     */
    public void setValor(int valor) {
        this.valor = valor;
    }
}
