package observer.janelas;

public class Main {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new Janela().setVisible(true);
        });
    }
}
